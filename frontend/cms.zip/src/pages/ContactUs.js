// Filename - pages/ContactUs.js

import React from "react";
//import './static/sidebar.css';

const Contact = () => {
	return (
		<div className="contact">
			<h1>GeeksforGeeks Contact us</h1>
		</div>
	);
};

export default Contact;
